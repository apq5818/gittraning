package Thirddemo;

public class Substraction {

	
		int sub(int first, int second) {
			return first-second;
		}
		
		int sub1(String first, String second) {
			//return first-second;
			int x=Integer.parseInt(first);
			int y=Integer.parseInt(second);
			return x-y;
		}
		
}
