package Thirddemo;


class Additoin{
	
	/**
	 * 
	 * @param first
	 * @param second
	 * @return
	 */
	int add(int first, int second) {
		return first+second;
	}
	
}