package Thirddemo;

import org.junit.Test;

public class AdditionTest {

	public AdditionTest() {
		// TODO Auto-generated constructor stub
	}
	
	@Test
	public void testAdd()  {
		Additoin additoin = new Additoin();
		System.out.println( additoin.add(1,2));
		
		
	}

}
