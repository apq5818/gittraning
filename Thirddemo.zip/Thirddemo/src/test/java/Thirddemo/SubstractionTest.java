package Thirddemo;

import org.junit.Test;

public class SubstractionTest {
	
	public SubstractionTest() {
		// TODO Auto-generated constructor stub
	}
	
	@Test
	public void subtest()  {
		Substraction substraction = new Substraction();
		
		System.out.println( substraction.sub(1,2));
		
		
		System.out.println( substraction.sub1("100","abc"));
		
		
	}


}
