package Thirddemo;

import org.junit.Test;

public class RomanTest {

	@Test
	public void romantest()  {
		
		for (int i = 1; i<= 100; i++) {
	        System.out.println(i+"\t =\t "+Roman.toRoman(i));
	    }
	}
	
}
